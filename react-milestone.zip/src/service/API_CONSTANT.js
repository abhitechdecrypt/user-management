export const BASE_URL = "http://localhost:9812/api/v1/user-Management/";
export const LIST_USER = "list-user";
export const GET_USER_BY_ID = "find-user";
export const UPDATE_USER = "update-user";
export const DELETE_USER_BY_ID = "delete-user";
export const CREATE_USER = "create-user";
