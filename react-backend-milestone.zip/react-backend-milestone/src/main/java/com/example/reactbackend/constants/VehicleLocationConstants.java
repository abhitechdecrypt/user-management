package com.example.reactbackend.constants;

public class VehicleLocationConstants {
	
	public static final String VEHICLE_LOCATION_TOPIC = "vehicle_location-1";

}
