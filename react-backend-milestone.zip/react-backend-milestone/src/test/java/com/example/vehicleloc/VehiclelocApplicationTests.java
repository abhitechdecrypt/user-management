package com.example.vehicleloc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehiclelocApplicationTests {

	@Test
	void contextLoads() {
	}

}
